package com.hagayproject.demo12.login;


public enum ClientType {
    ADMINSTRATOR,
    COMPANY,
    CUSTOMER;
}