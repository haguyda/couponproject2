package com.hagayproject.demo12.beans;


public enum Category {
    FOOD,
    ELECTRICITY,
    RESTAURANT,
    VACATION;
}